NOTE:

this is a demo version and it will not save ur data or print. so if u wnat to do some analysis and have a print of it or want to save it then u just make the entries in the demo version and after haveing completed ur work, just copy all the data or sheet to a new workbook and thats done. But this will not copy the formulas. So don't make nay changes after copying.

Fahad Dar

=========================================

Forecast and Budget Builder Excel
Version 2.1
from bizpeponline.com

*Outline*

The Forecast and Budget Builder is a streamlined tool for developing a 3 year business forecast and a 12 month budget. It requires minimal inputs and generates Optimistic to Pessimistic forecasts for your business. From your forecasts a 12 month master budget is built. You then have the capacity to refine this budget as required. The methodology used applies relationships between current data and relative indicators for future performance to produce a verifiable budget quickly and easily. This forecast and budget tool can be utilized for existing and proposed businesses, products, or services. Outputs include a 3 Year Forecast with Sensitivity Analysis, and a Budget by Month in tabular and graphical form.

*Evaluation*

Software is provide free for 7 Day Evaluation. To maintain software after this period payment is required. Print and Save functions are restricted during Evaluation.

*Install / Uninstall*

This model is in Microsoft Excel format. You must have Excel software installed on your computer. Software can be provided in alternative formats upon request to mail@bizpeponline.com. To use this software simply open the Excel file (.xls etension). Macros must be enabled for the model to function. No system files are changed when you use this software. To uninstall simply delete all associated unzipped and zipped files.

*Purchase*

To maintain software beyond the Evaluation Period payment must be provided equivalent to: US$30.00. If payment is not provided all software must be deleted. Payment gives you license to use software on one system, for one user. The license is for Non-commercial private and internal business use only. This license does not cover the Commercial use of software for Inter-Business support, advise, or consulting. Please contact us (mail@bizpeponline.com) for  details on Commercial and Multi-User licenses.

Payment is online at:

http://www.bizpeponline.com/Buy_Bizpeponline.htm

or by mailed check to BIZPEP, 15 Island View Court, Buderim, Queensland, 4556, Australia.  Please provide your email address and the name of the model you are purchasing with mailed payment.

Upon receipt of payment Bizpep will provide by return email Registration Code to maintain the software and enable all functions.

*Software Support*

Bizpep offer support for operation and application of registered software. Simply email your Registration Code and an outline of your question to: support@bizpeponline.com.

Bizpep also offer a result interpretation service, simply email us your input variables and we will provide an analysis by return email. The fee for this service is US$50.

*Intellectual Property*

Bizpep retain all intellectual property rights. It is prohibited to use the software, concepts, formats, and systems obtained from Bizpep in any manner outside their intended use as designed and defined by Bizpep. You may not modify, translate, reverse engineer, decompile, disassemble or create derivative works based on Bizpep software, services or concepts.

*Hold Harmless*

Bizpep provide tools to support business. The specific suitability of these tools must be independently assessed. Services including software, concepts, formats, and systems are provided as is and with no warranties of any kind, whether expressed or implied. The user must assume the entire risk of using Bizpep software or services, and agrees to hold Bizpep harmless from any claims or losses relating to service or software use. In no event shall Bizpep, its principals, distributors, employees, or other associated parties, be liable for any incidental, consequential, or punitive damages whatsoever relating to software or service use. In addition use of software and services is entirely at the users risk, and use acknowledges that Bizpep is held harmless from any claims or losses relating to software or services provided.

*Distribution*

You may freely distribute this software in Evaluation form without Registration Codes.  Any software distributed must require the user to provide payment to Bizpep to maintain software beyond the Evaluation Period as originally designed. You may not sell or require payment in any form for Bizpep software. Evaluation software must be distributed without cost or penalty to the user.

*Contact Details*

For software support email support@bizpeponline.com.

Additional business support models are available at
http://www.bizpeponline.com/

Software and vendor details are also available in the 
pad*****.htm file.  


Bizpep
15 Island View Court
Queensland, 4556, Australia.
Email:      mail@bizpeponline.com
Web Site:   www.bizpeponline.com
Telephone:  +617 5445 5325
  
Regards
David Morcom
bizpeponline.com