To run the dictionary
Run file edict.exe
